create
    definer = ssg@localhost procedure customer_level_case(IN customer_id_input int)
begin
    declare custormer_level varchar(10);
    declare amount_sum float;


    set amount_sum = (select sum(amount) from payment where customer_id = customer_id_input group by customer_id);

    case
        when amount_sum >= 150 then SET custormer_level = 'VVIP';
        when amount_sum >= 120 then SET custormer_level = 'VIP';
        when amount_sum >= 100 then SET custormer_level = 'GOLD';
        when amount_sum >= 80 then SET custormer_level = 'SILVER';
        else set custormer_level = 'Bronze';
       end case;

    select customer_id_input as customer_id, amount_sum, custormer_level;

    end;

