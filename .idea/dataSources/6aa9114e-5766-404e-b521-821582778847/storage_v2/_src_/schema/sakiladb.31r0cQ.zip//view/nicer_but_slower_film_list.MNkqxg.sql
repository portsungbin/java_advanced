create definer = sakiladb@localhost view nicer_but_slower_film_list as
select `sakiladb`.`film`.`film_id`                                                                                AS `FID`,
       `sakiladb`.`film`.`title`                                                                                  AS `title`,
       `sakiladb`.`film`.`description`                                                                            AS `description`,
       `sakiladb`.`category`.`name`                                                                               AS `category`,
       `sakiladb`.`film`.`rental_rate`                                                                            AS `price`,
       `sakiladb`.`film`.`length`                                                                                 AS `length`,
       `sakiladb`.`film`.`rating`                                                                                 AS `rating`,
       group_concat(concat(concat(upper(substr(`sakiladb`.`actor`.`first_name`, 1, 1)),
                                  lower(substr(`sakiladb`.`actor`.`first_name`, 2,
                                               length(`sakiladb`.`actor`.`first_name`))), _utf8mb4' ',
                                  concat(upper(substr(`sakiladb`.`actor`.`last_name`, 1, 1)),
                                         lower(substr(`sakiladb`.`actor`.`last_name`, 2,
                                                      length(`sakiladb`.`actor`.`last_name`)))))) separator
                    ', ')                                                                                         AS `actors`
from ((((`sakiladb`.`film` left join `sakiladb`.`film_category`
         on ((`sakiladb`.`film_category`.`film_id` = `sakiladb`.`film`.`film_id`))) left join `sakiladb`.`category`
        on ((`sakiladb`.`category`.`category_id` =
             `sakiladb`.`film_category`.`category_id`))) left join `sakiladb`.`film_actor`
       on ((`sakiladb`.`film`.`film_id` = `sakiladb`.`film_actor`.`film_id`))) left join `sakiladb`.`actor`
      on ((`sakiladb`.`film_actor`.`actor_id` = `sakiladb`.`actor`.`actor_id`)))
group by `sakiladb`.`film`.`film_id`, `sakiladb`.`category`.`name`;

