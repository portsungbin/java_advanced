create
    definer = ssg@localhost procedure value_while_leave(IN param1 int, IN paran2 int)
begin
    declare i INT;
    declare result INT;

    set i = 1;
    set result = 0;

    mywhile:
    while (i <= param1)
        do
            set result = result + paran2;
            set i = i + 1;

            if (result > 100)then leave mywhile;
            end if;
        end while;

    select result;

end;

