create
    definer = ssg@localhost procedure customer_if(IN customer_id_input int)
begin
declare store_id_i INT;
declare s_id_one INT;
declare s_id_two INT;

set store_id_i = (select store_id from customer where customer_id = customer_id_input);

if store_id_i = 1 then set s_id_one = 1;
else set s_id_two = 2;
end if;

select store_id_i, s_id_one, s_id_two;

end;

