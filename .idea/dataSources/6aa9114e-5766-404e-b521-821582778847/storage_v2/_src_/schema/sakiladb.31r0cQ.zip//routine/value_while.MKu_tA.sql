create
    definer = ssg@localhost procedure value_while(IN param1 int, IN paran2 int)
begin
    declare i INT;
    declare result INT;

    set i = 1;
    set result = 0;

    while (i <= param1) do set result = result + paran2; set i = i + 1;
        end while;

    select result;

end;

