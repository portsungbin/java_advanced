create
    definer = ssg@localhost procedure dynamic(IN t_name varchar(50), IN c_name varchar(50), IN customer_id int)
begin

    set @t_name = t_name;
    set @c_name = c_name;
    set @customer_id = customer_id;
    set @sql = concat('select', @c_name, 'from', @t_name, 'where customer_id = ', @customer_id);

    select @sql;
    prepare dynamic_query from @sql;
    execute dynamic_query;
    deallocate  prepare dynamic_query;
end;

